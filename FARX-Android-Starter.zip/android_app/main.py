from pathlib import Path
from kivy.app import App
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.utils import get_color_from_hex

from farx.lexer import Lexer
from farx.parser import Parser
from farx.runtime import Interpreter

STARTER = """MODE CODE
LET greeting = "Hello from FARX NEXUS"
LET answer = 6 * 7
PRINT greeting
PRINT answer
END MODE
"""


class FarxAndroidApp(App):
    def build(self):
        self.title = "FARX NEXUS"
        self.saved_file = Path(self.user_data_dir) / "program.farx"
        root = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        root.add_widget(Label(
            text="[b]FARX NEXUS[/b]  •  Offline Language Studio",
            markup=True, size_hint_y=None, height=dp(42)
        ))
        self.editor = TextInput(
            text=STARTER, multiline=True, font_size="15sp",
            size_hint_y=0.58,
            background_color=get_color_from_hex("#171923"),
            foreground_color=get_color_from_hex("#F4F4F5"),
            cursor_color=get_color_from_hex("#67E8F9"),
            padding=dp(10)
        )
        root.add_widget(self.editor)

        row1 = BoxLayout(size_hint_y=None, height=dp(46), spacing=dp(8))
        for caption, callback in (
            ("RUN FARX", self.run_code),
            ("SAVE", self.save_code),
            ("LOAD", self.load_code),
        ):
            btn = Button(text=caption)
            btn.bind(on_release=callback)
            row1.add_widget(btn)
        root.add_widget(row1)

        root.add_widget(Label(
            text="OUTPUT / TERMINAL", size_hint_y=None, height=dp(26)
        ))
        self.output = TextInput(
            text="Ready. FARX runs locally on this device.",
            readonly=True, multiline=True, size_hint_y=0.32,
            font_size="14sp",
            background_color=get_color_from_hex("#101318"),
            foreground_color=get_color_from_hex("#A7F3D0"),
            padding=dp(10)
        )
        root.add_widget(self.output)
        return root

    def run_code(self, *_):
        lines = []
        try:
            tree = Parser(Lexer(self.editor.text).tokens()).parse()
            Interpreter(
                output=lambda value: lines.append(str(value)),
                input_fn=lambda prompt="": ""
            ).run(tree)
            self.output.text = "\n".join(lines) if lines else "Program finished (no output)."
        except Exception as exc:
            self.output.text = f"FARX ERROR: {exc}"

    def save_code(self, *_):
        try:
            self.saved_file.write_text(self.editor.text, encoding="utf-8")
            self.output.text = f"Saved offline:\n{self.saved_file.name}"
        except Exception as exc:
            self.output.text = f"SAVE ERROR: {exc}"

    def load_code(self, *_):
        try:
            if self.saved_file.exists():
                self.editor.text = self.saved_file.read_text(encoding="utf-8")
                self.output.text = f"Loaded:\n{self.saved_file.name}"
            else:
                self.output.text = "No saved program yet. Tap SAVE first."
        except Exception as exc:
            self.output.text = f"LOAD ERROR: {exc}"


if __name__ == "__main__":
    FarxAndroidApp().run()
