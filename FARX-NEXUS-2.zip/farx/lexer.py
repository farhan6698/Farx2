from dataclasses import dataclass

KEYWORDS = {"MODE","CODE","END","LET","SET","PRINT","IF","THEN","ELSE",
            "WHILE","DO","FUNCTION","RETURN","TRUE","FALSE","NULL",
            "AND","OR","NOT","BREAK","CONTINUE"}

@dataclass
class Token:
    kind: str
    value: object
    line: int
    column: int

class FarxError(Exception):
    pass

class Lexer:
    def __init__(self, source):
        self.s, self.i, self.line, self.col, self.out = source, 0, 1, 1, []

    def peek(self, n=0):
        p = self.i+n
        return self.s[p] if p < len(self.s) else "\0"

    def advance(self):
        c = self.peek()
        self.i += 1
        if c == "\n": self.line += 1; self.col = 1
        else: self.col += 1
        return c

    def add(self, kind, value, line, col):
        self.out.append(Token(kind, value, line, col))

    def scan(self):
        while self.peek() != "\0":
            c = self.peek()
            if c in " \t\r": self.advance(); continue
            if c == "\n" or c == ";":
                ln, cl = self.line, self.col
                self.advance(); self.add("NEWLINE", "\n", ln, cl); continue
            if c == "#":
                while self.peek() not in ("\n", "\0"): self.advance()
                continue
            ln, cl = self.line, self.col
            if c.isdigit():
                start = self.i
                while self.peek().isdigit(): self.advance()
                if self.peek()=="." and self.peek(1).isdigit():
                    self.advance()
                    while self.peek().isdigit(): self.advance()
                raw = self.s[start:self.i]
                self.add("NUMBER", float(raw) if "." in raw else int(raw), ln, cl)
            elif c.isalpha() or c == "_":
                start = self.i
                while self.peek().isalnum() or self.peek()=="_": self.advance()
                word = self.s[start:self.i]
                upper = word.upper()
                self.add("KEYWORD" if upper in KEYWORDS else "IDENT",
                         upper if upper in KEYWORDS else word, ln, cl)
            elif c in "\"'":
                quote = self.advance()
                chars = []
                while self.peek() not in (quote, "\0"):
                    ch = self.advance()
                    if ch == "\\":
                        esc = self.advance()
                        mapping = {"n":"\n","t":"\t","r":"\r","\\":"\\",'"':'"',"'":"'"}
                        if esc not in mapping: raise FarxError(f"Bad escape at {self.line}:{self.col}")
                        chars.append(mapping[esc])
                    else: chars.append(ch)
                if self.peek() == "\0": raise FarxError(f"Unterminated string at {ln}:{cl}")
                self.advance()
                self.add("STRING", "".join(chars), ln, cl)
            else:
                two = c+self.peek(1)
                if two in ("==","!=","<=",">=","&&","||"):
                    self.advance(); self.advance(); self.add("OP", two, ln, cl)
                elif c in "+-*/%()[],=<>!":
                    self.advance(); self.add("OP", c, ln, cl)
                else: raise FarxError(f"Unknown character {c!r} at {ln}:{cl}")
        self.add("EOF", None, self.line, self.col)
        return self.out
