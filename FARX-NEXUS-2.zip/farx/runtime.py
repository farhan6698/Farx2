from .parser import parse
from .lexer import FarxError

class ReturnSignal(Exception):
    def __init__(self,v): self.value=v
class BreakSignal(Exception): pass
class ContinueSignal(Exception): pass

class Env:
    def __init__(self,parent=None): self.data,self.parent={},parent
    def define(self,n,v): self.data[n]=v
    def get(self,n):
        if n in self.data: return self.data[n]
        if self.parent: return self.parent.get(n)
        raise FarxError(f"Undefined variable: {n}")
    def set(self,n,v):
        if n in self.data: self.data[n]=v; return
        if self.parent: self.parent.set(n,v); return
        raise FarxError(f"Cannot SET undefined variable: {n}")

class Function:
    def __init__(self,p,b,e): self.params,self.body,self.env=p,b,e

class Interpreter:
    def __init__(self,out):
        self.out=out; self.steps=0; self.limit=100000; self.env=Env()
        self.env.define("LEN",lambda x:len(x))
        self.env.define("STR",lambda x:str(x))
        self.env.define("NUM",self.number)
        self.env.define("TYPE",lambda x:"NULL" if x is None else type(x).__name__.upper())
        self.env.define("ABS",abs); self.env.define("MIN",min); self.env.define("MAX",max)
    def number(self,x):
        try: return float(x) if "." in str(x) else int(x)
        except Exception: raise FarxError(f"Cannot convert {x!r} to number")
    def tick(self):
        self.steps+=1
        if self.steps>self.limit: raise FarxError("Execution limit reached (possible infinite loop)")
    def block(self,node,env):
        for s in node.children or []: self.tick(); self.stmt(s,env)
    def stmt(self,n,e):
        k=n.kind
        if k=="let": e.define(n.value,self.val(n.children[0],e))
        elif k=="set": e.set(n.value,self.val(n.children[0],e))
        elif k=="print": self.out(self.show(self.val(n.children[0],e)))
        elif k=="if": self.block(n.children[1] if self.val(n.children[0],e) else n.children[2],Env(e))
        elif k=="while":
            loops=0
            while self.val(n.children[0],e):
                loops+=1
                if loops>self.limit: raise FarxError("Loop limit reached")
                try: self.block(n.children[1],Env(e))
                except ContinueSignal: continue
                except BreakSignal: break
        elif k=="function": e.define(n.value,Function(n.children[0],n.children[1],e))
        elif k=="return": raise ReturnSignal(self.val(n.children[0],e) if n.children else None)
        elif k=="break": raise BreakSignal()
        elif k=="continue": raise ContinueSignal()
    def val(self,n,e):
        k=n.kind
        if k=="literal": return n.value
        if k=="variable": return e.get(n.value)
        if k=="unary":
            v=self.val(n.children[0],e)
            return -v if n.value=="-" else (+v if n.value=="+" else not v)
        if k=="binary":
            a=self.val(n.children[0],e)
            if n.value in ("AND","&&"): return bool(a) and bool(self.val(n.children[1],e))
            if n.value in ("OR","||"): return bool(a) or bool(self.val(n.children[1],e))
            b=self.val(n.children[1],e)
            funcs={"+":lambda:a+b,"-":lambda:a-b,"*":lambda:a*b,"/":lambda:a/b,"%":lambda:a%b,
                   "==":lambda:a==b,"!=":lambda:a!=b,"<":lambda:a<b,"<=":lambda:a<=b,">":lambda:a>b,">=":lambda:a>=b}
            try: return funcs[n.value]()
            except ZeroDivisionError: raise FarxError("Division by zero")
            except Exception as ex: raise FarxError(f"Invalid operation: {ex}")
        if k=="call":
            fn=e.get(n.value); args=[self.val(x,e) for x in n.children]
            if isinstance(fn,Function):
                if len(args)!=len(fn.params): raise FarxError(f"{n.value} expects {len(fn.params)} arguments")
                local=Env(fn.env)
                for p,v in zip(fn.params,args): local.define(p,v)
                try: self.block(fn.body,local)
                except ReturnSignal as r: return r.value
                return None
            if callable(fn):
                try: return fn(*args)
                except Exception as ex: raise FarxError(f"Built-in {n.value} failed: {ex}")
            raise FarxError(f"{n.value} is not callable")
        raise FarxError("Invalid expression")
    def show(self,v):
        if v is True: return "TRUE"
        if v is False: return "FALSE"
        if v is None: return "NULL"
        return str(v)

def run_source(source, output=None):
    tree=parse(source)
    Interpreter(output or (lambda x:None)).block(tree,Env())
