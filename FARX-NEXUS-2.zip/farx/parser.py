from dataclasses import dataclass
from .lexer import Lexer, FarxError

@dataclass
class Node:
    kind: str
    value: object = None
    children: list = None
    line: int = 0

class Parser:
    PREC = {"OR":1,"||":1,"AND":2,"&&":2,"==":3,"!=":3,
            "<":4,"<=":4,">":4,">=":4,"+":5,"-":5,"*":6,"/":6,"%":6}
    def __init__(self, tokens): self.t, self.i = tokens, 0
    def cur(self): return self.t[self.i]
    def take(self): x=self.cur(); self.i+=1; return x
    def is_(self, v): return self.cur().value == v
    def match(self, *v):
        if self.is_any(*v): return self.take()
        return None
    def is_any(self, *v): return self.cur().value in v
    def expect(self, v):
        if not self.is_(v):
            t=self.cur(); raise FarxError(f"Expected {v}, got {t.value!r} at {t.line}:{t.column}")
        return self.take()
    def ident(self):
        t=self.cur()
        if t.kind!="IDENT": raise FarxError(f"Expected identifier at {t.line}:{t.column}")
        return self.take().value
    def sep(self):
        while self.cur().kind=="NEWLINE": self.take()
    def parse(self):
        self.sep()
        wrapped = bool(self.match("MODE"))
        if wrapped: self.expect("CODE"); self.sep()
        body=self.block({"END"} if wrapped else set())
        if wrapped: self.expect("END"); self.expect("MODE")
        self.sep()
        if self.cur().kind!="EOF":
            t=self.cur(); raise FarxError(f"Unexpected token at {t.line}:{t.column}")
        return Node("block", children=body)
    def block(self, stops):
        out=[]
        while self.cur().kind!="EOF" and self.cur().value not in stops:
            if self.cur().kind=="NEWLINE": self.sep(); continue
            out.append(self.statement())
            if self.cur().kind not in ("NEWLINE","EOF") and self.cur().value not in stops:
                t=self.cur(); raise FarxError(f"Expected end of line at {t.line}:{t.column}")
            self.sep()
        return out
    def statement(self):
        t=self.cur()
        if self.match("LET"):
            n=self.ident(); self.expect("="); return Node("let",n,[self.expr()],t.line)
        if self.match("SET"):
            n=self.ident(); self.expect("="); return Node("set",n,[self.expr()],t.line)
        if self.match("PRINT"): return Node("print",children=[self.expr()],line=t.line)
        if self.match("IF"):
            cond=self.expr(); self.expect("THEN"); self.sep()
            yes=self.block({"ELSE","END"}); no=[]
            if self.match("ELSE"): self.sep(); no=self.block({"END"})
            self.expect("END"); self.expect("IF")
            return Node("if",children=[cond,Node("block",children=yes),Node("block",children=no)],line=t.line)
        if self.match("WHILE"):
            cond=self.expr(); self.expect("DO"); self.sep()
            body=self.block({"END"}); self.expect("END"); self.expect("WHILE")
            return Node("while",children=[cond,Node("block",children=body)],line=t.line)
        if self.match("FUNCTION"):
            name=self.ident(); self.expect("("); params=[]
            if not self.is_(")"):
                params.append(self.ident())
                while self.match(","): params.append(self.ident())
            self.expect(")"); self.sep(); body=self.block({"END"})
            self.expect("END"); self.expect("FUNCTION")
            return Node("function",name,[params,Node("block",children=body)],t.line)
        if self.match("RETURN"):
            return Node("return",children=[] if self.cur().kind in ("NEWLINE","EOF") else [self.expr()],line=t.line)
        if self.match("BREAK"): return Node("break",line=t.line)
        if self.match("CONTINUE"): return Node("continue",line=t.line)
        raise FarxError(f"Unknown statement {t.value!r} at {t.line}:{t.column}")
    def expr(self, minp=0):
        t=self.take()
        if t.kind in ("NUMBER","STRING"): left=Node("literal",t.value,line=t.line)
        elif t.value in ("TRUE","FALSE","NULL"):
            left=Node("literal",{"TRUE":True,"FALSE":False,"NULL":None}[t.value],line=t.line)
        elif t.value in ("-","+","!","NOT"): left=Node("unary",t.value,[self.expr(7)],t.line)
        elif t.value=="(":
            left=self.expr(); self.expect(")")
        elif t.kind=="IDENT":
            if self.match("("):
                args=[]
                if not self.is_(")"):
                    args.append(self.expr())
                    while self.match(","): args.append(self.expr())
                self.expect(")"); left=Node("call",t.value,args,t.line)
            else: left=Node("variable",t.value,line=t.line)
        else: raise FarxError(f"Expected expression at {t.line}:{t.column}")
        while True:
            op=self.cur().value; p=self.PREC.get(op,-1)
            if p<minp: break
            self.take(); right=self.expr(p+1); left=Node("binary",op,[left,right],t.line)
        return left

def parse(source): return Parser(Lexer(source).scan()).parse()
