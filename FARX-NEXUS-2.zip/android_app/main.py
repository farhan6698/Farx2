import os
from kivy.app import App
from kivy.metrics import dp
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.filechooser import FileChooserListView
from farx import run_source

BG="#0B1020"; PANEL="#131B2E"; PANEL2="#1A2540"
ACCENT="#7658F5"; CYAN="#45D6D0"; WHITE="#EAF0FF"; MUTED="#93A4C4"
def C(v): return get_color_from_hex(v)

STARTER = "MODE CODE\\nLET title = \\"FARX NEXUS 2\\"\\nLET answer = 6 * 7\\nPRINT \\"Welcome to \\" + title\\nPRINT answer\\nIF answer == 42 THEN\\n    PRINT \\"FARX RUNTIME ONLINE\\"\\nELSE\\n    PRINT \\"CHECK FAILED\\"\\nEND IF\\nFUNCTION square(value)\\n    RETURN value * value\\nEND FUNCTION\\nPRINT square(9)\\nEND MODE\\n"

class FARXApp(App):
    def build(self):
        self.title="FARX NEXUS 2"; Window.clearcolor=C(BG); self.path=None
        root=BoxLayout(orientation="vertical",padding=dp(13),spacing=dp(9))
        head=BoxLayout(size_hint_y=None,height=dp(54))
        brand=BoxLayout(orientation="vertical")
        brand.add_widget(Label(text="[b]FARX[/b] [color=#7658F5]NEXUS 2[/color]",markup=True,color=C(WHITE),font_size="21sp",halign="left"))
        brand.add_widget(Label(text="LANGUAGE STUDIO  •  ANDROID",color=C(MUTED),font_size="9sp",halign="left"))
        head.add_widget(brand)
        self.status=Label(text="● READY",color=C(CYAN),size_hint_x=None,width=dp(85),font_size="10sp")
        head.add_widget(self.status); root.add_widget(head)
        bar=GridLayout(cols=4,spacing=dp(6),size_hint_y=None,height=dp(43))
        for title,bg,fn in [("▶ RUN",ACCENT,self.run_code),("＋ NEW",PANEL2,self.new_file),("SAVE",PANEL2,self.save_file),("OPEN",PANEL2,self.open_file)]:
            bar.add_widget(self.button(title,bg,fn))
        root.add_widget(bar)
        self.editor=TextInput(text=STARTER,multiline=True,font_name="RobotoMono",font_size="14sp",
            foreground_color=C(WHITE),background_color=C(PANEL),cursor_color=C(CYAN),
            selection_color=C(ACCENT),padding=dp(12),size_hint_y=.59)
        root.add_widget(self.editor)
        ch=BoxLayout(size_hint_y=None,height=dp(28))
        ch.add_widget(Label(text="[b]OUTPUT CONSOLE[/b]",markup=True,color=C(MUTED),font_size="10sp",halign="left"))
        ch.add_widget(self.button("CLEAR",PANEL2,self.clear_console,width=dp(70)))
        root.add_widget(ch)
        self.console=TextInput(text="FARX NEXUS 2 • Ready.\\nPress RUN to execute.",readonly=True,multiline=True,
            font_name="RobotoMono",font_size="12sp",foreground_color=C(CYAN),
            background_color=C("#070B15"),padding=dp(10),size_hint_y=.24)
        root.add_widget(self.console)
        root.add_widget(Label(text="FARX LANGUAGE ENGINE  •  .farx",color=C(MUTED),font_size="9sp",size_hint_y=None,height=dp(20),halign="left"))
        return root

    def button(self,text,bg,fn,width=None):
        b=Button(text=text,size_hint_x=1 if width is None else None,width=width,
            size_hint_y=None,height=dp(43),background_normal="",background_color=C(bg),
            color=C(WHITE),bold=True,font_size="11sp")
        b.bind(on_release=lambda *_:fn()); return b
    def log(self,s): self.console.text += "\\n"+str(s)
    def run_code(self):
        self.console.text="FARX NEXUS 2 / EXECUTION\\n"+"─"*27
        self.status.text="● RUNNING"
        try:
            run_source(self.editor.text,self.log)
            self.log("─"*27); self.log("✓ Execution completed."); self.status.text="● SUCCESS"
        except Exception as ex:
            self.log("ERROR: "+str(ex)); self.status.text="● ERROR"
    def clear_console(self): self.console.text="Console cleared."
    def new_file(self): self.editor.text="MODE CODE\\n\\nEND MODE\\n"; self.path=None; self.console.text="New FARX file."
    def save_file(self):
        if self.path: self.write(self.path)
        else: self.file_popup(True)
    def open_file(self): self.file_popup(False)
    def write(self,path):
        try:
            with open(path,"w",encoding="utf-8") as f:f.write(self.editor.text)
            self.path=path; self.log("Saved: "+os.path.basename(path))
        except Exception as ex:self.log("Save error: "+str(ex))
    def file_popup(self,save):
        base=self.user_data_dir
        chooser=FileChooserListView(path=base,filters=["*.farx"],dirselect=False)
        box=BoxLayout(orientation="vertical",spacing=dp(7),padding=dp(8)); box.add_widget(chooser)
        pop=Popup(title="Save FARX file" if save else "Open FARX file",content=box,size_hint=(.94,.82))
        actions=BoxLayout(size_hint_y=None,height=dp(43),spacing=dp(7))
        actions.add_widget(self.button("CANCEL",PANEL2,pop.dismiss))
        def choose():
            path=chooser.selection[0] if chooser.selection else os.path.join(base,"untitled.farx")
            if save:
                if not path.lower().endswith(".farx"):path+=".farx"
                self.write(path)
            else:
                try:
                    with open(path,"r",encoding="utf-8") as f:self.editor.text=f.read()
                    self.path=path; self.log("Opened: "+os.path.basename(path))
                except Exception as ex:self.log("Open error: "+str(ex))
            pop.dismiss()
        actions.add_widget(self.button("SELECT",ACCENT,choose)); box.add_widget(actions); pop.open()

if __name__=="__main__": FARXApp().run()
