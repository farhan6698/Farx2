[app]
title = FARX NEXUS 2
package.name = farxnexus
package.domain = org.farx
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,farx
version = 2.0.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a
android.accept_sdk_license = True
android.allow_backup = False
android.debug_artifact = apk
p4a.branch = develop

[buildozer]
log_level = 2
warn_on_root = 1
