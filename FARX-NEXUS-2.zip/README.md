# FARX NEXUS 2
Standalone FARX language runtime + modern Android IDE starter.

- `farx/`: lexer, parser, AST-style nodes and runtime for the FARX language.
- `android_app/`: Kivy Android editor, run console, open/save `.farx`.
- `.github/workflows/build-android.yml`: GitHub Actions APK build.

Python is the current implementation language for the engine and Android host. FARX has its own syntax, lexer, parser and runtime; FARX programs are not Python source and are not translated into Python.

Example:
```farx
MODE CODE
LET name = "FARX NEXUS"
LET answer = 6 * 7
PRINT "Welcome to " + name
PRINT answer
IF answer == 42 THEN
    PRINT "Runtime online"
ELSE
    PRINT "Check failed"
END IF
FUNCTION square(value)
    RETURN value * value
END FUNCTION
PRINT square(9)
END MODE
```

The ZIP is source code, not an APK. Upload it to the root of `farhan6698/Farx2`, then add/replace `.github/workflows/build-android.yml` from this bundle. Run the workflow from Actions and download artifact `FARX-NEXUS-2-APK`.
