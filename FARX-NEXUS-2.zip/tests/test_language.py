import unittest
from farx import run_source

class Tests(unittest.TestCase):
    def run_farx(self, src):
        output=[]
        run_source(src, output.append)
        return output
    def test_math(self):
        self.assertEqual(self.run_farx("LET x = 6 * 7\nPRINT x"), ["42"])
    def test_function(self):
        src="FUNCTION sq(x)\nRETURN x*x\nEND FUNCTION\nPRINT sq(5)"
        self.assertEqual(self.run_farx(src), ["25"])
    def test_loop(self):
        src="LET n=0\nWHILE n < 3 DO\nPRINT n\nSET n=n+1\nEND WHILE"
        self.assertEqual(self.run_farx(src), ["0","1","2"])
    def test_if(self):
        self.assertEqual(self.run_farx('IF 2 > 1 THEN\nPRINT "yes"\nELSE\nPRINT "no"\nEND IF'), ["yes"])

if __name__=="__main__": unittest.main()
