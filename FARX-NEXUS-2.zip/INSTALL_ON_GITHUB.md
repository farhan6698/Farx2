# GitHub installation
1. Upload `FARX-NEXUS-2.zip` to the root of `farhan6698/Farx2`.
2. Create/replace `.github/workflows/build-android.yml` using the file at the same path inside this ZIP.
3. Commit both changes.
4. Open Actions → Build FARX NEXUS 2 APK → Run workflow.
5. After a green run, download artifact `FARX-NEXUS-2-APK`, extract it, and install the APK.
Do not upload the APK to the repository. GitHub Actions stores it as an artifact.
